package org.example.Exception;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String employeeNotFound) {
    }
}
